(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/publications.js                                              //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.publish('messages', function (course) {                         // 1
  return Messages.find({ course: course });                            // 2
});                                                                    //
                                                                       //
Meteor.publish('courses', function () {                                // 5
  return Courses.find();                                               // 6
});                                                                    //
                                                                       //
Meteor.publish("allUsernames", function () {                           // 9
  return Meteor.users.find({}, { fields: {                             // 10
      "username": 1,                                                   // 11
      "services.facebook.username": 1,                                 // 12
      "services.twitter.username": 1,                                  // 13
      "services.google.username": 1                                    // 14
    } });                                                              //
});                                                                    //
                                                                       //
//temporary                                                            //
Meteor.publish('profile', function () {                                // 19
  return Meteor.users.find();                                          // 20
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=publications.js.map
