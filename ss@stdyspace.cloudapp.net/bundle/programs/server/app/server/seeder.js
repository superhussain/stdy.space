(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/seeder.js                                                    //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.startup(function () {                                           // 1
                                                                       //
  Meteor.users.remove({});                                             // 3
  Accounts.createUser({                                                // 4
    username: "admin",                                                 // 5
    email: "test@test.com",                                            // 6
    password: "password"                                               // 7
  });                                                                  //
                                                                       //
  // Factory.define('message', Messages, {                             //
  //   text: function() {                                              //
  //   	return Fake.sentence();                                        //
  //   },                                                              //
  //   user: Meteor.users.findOne()._id,                               //
  //   timestamp: Date.now(),                                          //
  //   course: 'EECS1001'                                              //
  // });                                                               //
                                                                       //
  // Add this if you want to remove all messages before seeding        //
  // Messages.remove({});                                              //
  //                                                                   //
  // if (Messages.find({}).count() === 0) {                            //
  //   _(10).times(function(n) {                                       //
  //     Factory.create('message');                                    //
  //   });                                                             //
  // }                                                                 //
                                                                       //
  Courses.remove({});                                                  // 28
  Courses.insert({                                                     // 29
    name: "EECS1001"                                                   // 30
  });                                                                  //
  Courses.insert({                                                     // 32
    name: "EECS1011"                                                   // 33
  });                                                                  //
  Courses.insert({                                                     // 35
    name: "EECS1012"                                                   // 36
  });                                                                  //
  Courses.insert({                                                     // 38
    name: "EECS1019"                                                   // 39
  });                                                                  //
  Courses.insert({                                                     // 41
    name: "EECS1021"                                                   // 42
  });                                                                  //
  Courses.insert({                                                     // 44
    name: "EECS1022"                                                   // 45
  });                                                                  //
  Courses.insert({                                                     // 47
    name: "EECS1028"                                                   // 48
  });                                                                  //
  Courses.insert({                                                     // 50
    name: "EECS1030"                                                   // 51
  });                                                                  //
                                                                       //
  // Upload to Server                                                  //
                                                                       //
  UploadServer.init({                                                  // 56
    tmpDir: process.env.PWD + '/public/tmp',                           // 57
    uploadDir: process.env.PWD + '/public/uploads',                    // 58
    checkCreateDirectories: true                                       // 59
  });                                                                  //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=seeder.js.map
